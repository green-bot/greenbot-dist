var require = meteorInstall({"lib":{"collections":{"admin_users.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/collections/admin_users.js                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
AdminUsers = new Mongo.Collection('AdminUsers');                                                                     // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"bots.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/collections/bots.js                                                                                           //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Bots = new Mongo.Collection('Bots');                                                                                 // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"customers.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/collections/customers.js                                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
CustomerAccounts = new Mongo.Collection('Customers');                                                                // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"network_handles.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/collections/network_handles.js                                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
NetworkHandles = new Mongo.Collection('NetworkHandles');                                                             // 1
                                                                                                                     //
NetworkHandles.helpers({                                                                                             // 3
  name: function () {                                                                                                // 4
    function name() {                                                                                                //
      return this.handle + '@' + this.network;                                                                       // 5
    }                                                                                                                //
                                                                                                                     //
    return name;                                                                                                     //
  }()                                                                                                                //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"networks.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/collections/networks.js                                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Networks = new Mongo.Collection('Networks');                                                                         // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"number_porting_requests.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/collections/number_porting_requests.js                                                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
NumberPortingRequests = new Mongo.Collection('NumberPortingRequests');                                               // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"rooms.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/collections/rooms.js                                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Rooms = new Mongo.Collection('Rooms');                                                                               // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"scripts.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/collections/scripts.js                                                                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Scripts = new Mongo.Collection('Scripts');                                                                           // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"sessions.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/collections/sessions.js                                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Sessions = new Mongo.Collection('Sessions');                                                                         // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"router.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/router.js                                                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Router.route('/bots/:_id/addresses/:networkHandleName', {                                                            // 1
  name: 'networkAddressShow',                                                                                        // 2
  waitOn: function () {                                                                                              // 3
    function waitOn() {                                                                                              //
      return Meteor.subscribe("bot", this.params._id);                                                               // 3
    }                                                                                                                //
                                                                                                                     //
    return waitOn;                                                                                                   //
  }(),                                                                                                               //
  data: function () {                                                                                                // 4
    function data() {                                                                                                //
      return Bots.findOne();                                                                                         // 4
    }                                                                                                                //
                                                                                                                     //
    return data;                                                                                                     //
  }(),                                                                                                               //
  action: function () {                                                                                              // 5
    function action() {                                                                                              //
      this.render('networkAddressShow');                                                                             // 5
    }                                                                                                                //
                                                                                                                     //
    return action;                                                                                                   //
  }()                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
// ********** NPR *************                                                                                      //
Router.route('/number_porting_requests', {                                                                           // 10
  name: 'numberPortingRequestList',                                                                                  // 11
  waitOn: function () {                                                                                              // 12
    function waitOn() {                                                                                              //
      Meteor.subscribe("numberPortingRequests");                                                                     // 12
    }                                                                                                                //
                                                                                                                     //
    return waitOn;                                                                                                   //
  }(),                                                                                                               //
  action: function () {                                                                                              // 13
    function action() {                                                                                              //
      this.render('numberPortingRequestList');                                                                       // 13
    }                                                                                                                //
                                                                                                                     //
    return action;                                                                                                   //
  }()                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
Router.route('/number_porting_requests/new', {                                                                       // 16
  name: 'numberPortingRequestNew',                                                                                   // 17
  action: function () {                                                                                              // 18
    function action() {                                                                                              //
      this.render('numberPortingRequestNew');                                                                        // 18
    }                                                                                                                //
                                                                                                                     //
    return action;                                                                                                   //
  }()                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
Router.route('/number_porting_requests/:_id/edit', {                                                                 // 21
  name: 'numberPortingRequestEdit',                                                                                  // 22
  layoutTemplate: 'noAuthLayout',                                                                                    // 23
  waitOn: function () {                                                                                              // 24
    function waitOn() {                                                                                              //
      Meteor.subscribe("numberPortingRequest", this.params._id);                                                     // 25
    }                                                                                                                //
                                                                                                                     //
    return waitOn;                                                                                                   //
  }(),                                                                                                               //
  data: function () {                                                                                                // 27
    function data() {                                                                                                //
      return NumberPortingRequests.findOne(this.params._id);                                                         // 27
    }                                                                                                                //
                                                                                                                     //
    return data;                                                                                                     //
  }(),                                                                                                               //
  action: function () {                                                                                              // 28
    function action() {                                                                                              //
      this.render('numberPortingRequestEdit');                                                                       // 28
    }                                                                                                                //
                                                                                                                     //
    return action;                                                                                                   //
  }(),                                                                                                               //
                                                                                                                     //
  controller: 'UnauthenticatedController'                                                                            // 29
});                                                                                                                  //
                                                                                                                     //
Router.route('/number_porting_requests/:_id', {                                                                      // 32
  name: 'numberPortingRequestShow',                                                                                  // 33
  layoutTemplate: 'noAuthLayout',                                                                                    // 34
  waitOn: function () {                                                                                              // 35
    function waitOn() {                                                                                              //
      Meteor.subscribe("numberPortingRequest", this.params._id);                                                     // 36
    }                                                                                                                //
                                                                                                                     //
    return waitOn;                                                                                                   //
  }(),                                                                                                               //
  data: function () {                                                                                                // 38
    function data() {                                                                                                //
      return NumberPortingRequests.findOne(this.params._id);                                                         // 38
    }                                                                                                                //
                                                                                                                     //
    return data;                                                                                                     //
  }(),                                                                                                               //
  action: function () {                                                                                              // 39
    function action() {                                                                                              //
      this.render('numberPortingRequestShow');                                                                       // 39
    }                                                                                                                //
                                                                                                                     //
    return action;                                                                                                   //
  }(),                                                                                                               //
                                                                                                                     //
  controller: 'UnauthenticatedController'                                                                            // 40
});                                                                                                                  //
// ------------ END --------------                                                                                   //
                                                                                                                     //
Router.route('/port_start_notifications/new', {                                                                      // 44
  name: 'portStartNotificationNew',                                                                                  // 45
  action: function () {                                                                                              // 46
    function action() {                                                                                              //
      this.render('portStartNotificationNew');                                                                       // 46
    }                                                                                                                //
                                                                                                                     //
    return action;                                                                                                   //
  }(),                                                                                                               //
  waitOn: function () {                                                                                              // 47
    function waitOn() {                                                                                              //
      Meteor.subscribe('numberPortingRequestsByIds', Session.get('nprIdsToPort'));                                   // 47
    }                                                                                                                //
                                                                                                                     //
    return waitOn;                                                                                                   //
  }()                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
// ********** Accounts ********** //                                                                                 //
Router.route('/accounts/new', {                                                                                      // 51
  name: 'accountsNew',                                                                                               // 52
  action: function () {                                                                                              // 53
    function action() {                                                                                              //
      this.render('accountsNew');                                                                                    // 53
    }                                                                                                                //
                                                                                                                     //
    return action;                                                                                                   //
  }()                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
Router.route('/accounts/:_id', {                                                                                     // 57
  name: 'accountPage',                                                                                               // 58
  waitOn: function () {                                                                                              // 59
    function waitOn() {                                                                                              //
      Meteor.subscribe("account", this.params._id);                                                                  // 60
      Meteor.subscribe("bots", this.params._id);                                                                     // 61
      Meteor.subscribe("networkHandles", this.params._id);                                                           // 62
      Meteor.subscribe("scripts");                                                                                   // 63
    }                                                                                                                //
                                                                                                                     //
    return waitOn;                                                                                                   //
  }(),                                                                                                               //
  data: function () {                                                                                                // 65
    function data() {                                                                                                //
      return Meteor.users.findOne(this.params._id);                                                                  // 65
    }                                                                                                                //
                                                                                                                     //
    return data;                                                                                                     //
  }(),                                                                                                               //
  action: function () {                                                                                              // 66
    function action() {                                                                                              //
      this.render('accountPage');                                                                                    // 66
    }                                                                                                                //
                                                                                                                     //
    return action;                                                                                                   //
  }()                                                                                                                //
});                                                                                                                  //
// ---------- END -------------                                                                                      //
                                                                                                                     //
Router.route('/conversations/:_id', {                                                                                // 70
  waitOn: function () {                                                                                              // 71
    function waitOn() {                                                                                              //
      Meteor.subscribe("session", this.params._id);                                                                  // 71
    }                                                                                                                //
                                                                                                                     //
    return waitOn;                                                                                                   //
  }(),                                                                                                               //
  data: function () {                                                                                                // 72
    function data() {                                                                                                //
      return Sessions.findOne();                                                                                     // 72
    }                                                                                                                //
                                                                                                                     //
    return data;                                                                                                     //
  }(),                                                                                                               //
  action: function () {                                                                                              // 73
    function action() {                                                                                              //
      this.render('conversationDetails');                                                                            // 73
    }                                                                                                                //
                                                                                                                     //
    return action;                                                                                                   //
  }()                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
Router.route('/network_handles/:accountId', {                                                                        // 76
  waitOn: function () {                                                                                              // 77
    function waitOn() {                                                                                              //
      Meteor.subscribe("networkHandles", this.params.accountId);                                                     // 78
      Meteor.subscribe("rooms", this.params.accountId);                                                              // 79
    }                                                                                                                //
                                                                                                                     //
    return waitOn;                                                                                                   //
  }(),                                                                                                               //
  data: function () {                                                                                                // 81
    function data() {                                                                                                //
      return CustomerAccounts.findOne(this.params.accountId);                                                        // 81
    }                                                                                                                //
                                                                                                                     //
    return data;                                                                                                     //
  }(),                                                                                                               //
  action: function () {                                                                                              // 82
    function action() {                                                                                              //
      this.render('networkHandlePage');                                                                              // 82
    }                                                                                                                //
                                                                                                                     //
    return action;                                                                                                   //
  }()                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
Router.route('/', {                                                                                                  // 85
  name: 'home',                                                                                                      // 86
  action: function () {                                                                                              // 87
    function action() {                                                                                              // 87
      this.redirect('/dashboard');                                                                                   // 87
    }                                                                                                                //
                                                                                                                     //
    return action;                                                                                                   //
  }()                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
Router.configure({                                                                                                   // 91
  layoutTemplate: 'masterLayout',                                                                                    // 92
  loadingTemplate: 'loading',                                                                                        // 93
  controller: 'AuthenticatedController'                                                                              // 94
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"api":{"1_restivus-init.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/api/1_restivus-init.js                                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
restApi = new Restivus({                                                                                             // 1
  useDefaultAuth: true,                                                                                              // 2
  prettyJson: true                                                                                                   // 3
});                                                                                                                  //
                                                                                                                     //
restApi.addCollection(Sessions, { path: 'sessions' });                                                               // 6
restApi.addCollection(Scripts, { path: 'scripts' });                                                                 // 7
restApi.addCollection(Bots, { path: 'bots' });                                                                       // 8
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"plivo.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/api/plivo.js                                                                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var plivo = Npm.require('plivo');                                                                                    // 1
                                                                                                                     //
restApi.addRoute('plivo/new_call', { authRequired: false }, {                                                        // 4
  post: {                                                                                                            // 5
    action: function () {                                                                                            // 6
      function action() {                                                                                            // 6
        var response = plivo.Response();                                                                             // 7
        var number = this.bodyParams.CallerName;                                                                     // 8
        var portingRequest = NumberPortingRequests.findOne({ number: number });                                      // 9
        if (portingRequest) {                                                                                        // 10
          var sayNameMessage = "Hello, thank you for using kisst. Please say your full name after the beep and press pound to confirm your number porting request.";
          response.addSpeak(sayNameMessage);                                                                         // 12
          response.addRecord({                                                                                       // 13
            action: 'http://104.131.57.1:3001/api/plivo/recording_complete',                                         // 14
            maxLength: 10,                                                                                           // 15
            playBeep: true                                                                                           // 16
          });                                                                                                        //
        } else {                                                                                                     //
          var notFoundMessage = "Hello, you have reached kisst's number porting service. Unfortunately we were unable to find a porting request for the number you called from " + number + ".  Please ensure that you have already made a number porting request and that you are calling from that number.";
          response.addSpeak(notFoundMessage);                                                                        // 20
        }                                                                                                            //
                                                                                                                     //
        return xmlResponse(response);                                                                                // 23
      }                                                                                                              //
                                                                                                                     //
      return action;                                                                                                 //
    }()                                                                                                              //
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
function xmlResponse(plivoResponse) {                                                                                // 28
  return {                                                                                                           // 29
    headers: {                                                                                                       // 30
      'Content-Type': 'application/xml; charset=utf-8'                                                               // 31
    },                                                                                                               //
    body: '<?xml version="1.0" encoding="UTF-8" ?>' + plivoResponse.toXML()                                          // 33
  };                                                                                                                 //
}                                                                                                                    //
                                                                                                                     //
restApi.addRoute('plivo/recording_complete', { authRequired: false }, {                                              // 37
  post: {                                                                                                            // 38
    action: function () {                                                                                            // 39
      function action() {                                                                                            // 39
        var response = plivo.Response();                                                                             // 40
        var number = this.bodyParams.CallerName;                                                                     // 41
        var portingRequest = NumberPortingRequests.findOne({ number: number });                                      // 42
        response.addSpeak("Thank you for confirming your ownership. We will now proceed with porting your number.");
                                                                                                                     //
        var now = new Date();                                                                                        // 45
        NumberPortingRequests.update({ _id: portingRequest._id }, { $set: { ownershipConfirmedAt: now, recordingUrl: this.bodyParams.RecordUrl } });
                                                                                                                     //
        Email.send({                                                                                                 // 48
          to: 'porting@green-bot.com',                                                                               // 49
          from: "noreply@green-bot.com",                                                                             // 50
          subject: 'request to port ' + portingRequest.number                                                        // 51
        });                                                                                                          //
                                                                                                                     //
        return xmlResponse(response);                                                                                // 54
      }                                                                                                              //
                                                                                                                     //
      return action;                                                                                                 //
    }()                                                                                                              //
  }                                                                                                                  //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"config":{"environment.coffee":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/config/environment.coffee.js                                                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.settings["public"].GREENBOT_IO_URL = process.env.GREENBOT_IO_URL || 'http://localhost:3003';                  // 1
                                                                                                                     //
Meteor.settings.NPM_GLOBAL_PATH = process.env.NPM_GLOBAL_PATH || '/usr/local/lib/node_modules';                      // 1
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"emails":{"confirm_loa.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/emails/confirm_loa.js                                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
SSR.compileTemplate('confirmLoaBody', Assets.getText('emails/confirm_loa.html'));                                    // 1
                                                                                                                     //
Meteor.methods({                                                                                                     // 3
  sendConfirmLoaEmail: function () {                                                                                 // 4
    function sendConfirmLoaEmail(numberPortingRequest) {                                                             // 4
      this.unblock();                                                                                                // 5
                                                                                                                     //
      // don’t allow sending email unless the user is logged in                                                      //
      if (!Meteor.user()) throw new Meteor.Error(403, "not logged in");                                              // 4
      var account = CustomerAccounts.findOne(numberPortingRequest.accountId);                                        // 9
      var host = 'http://104.131.57.1:3001';                                                                         // 10
      var editNumberPortingRequestUrl = host + Router.routes.numberPortingRequestEdit.path({ _id: numberPortingRequest._id.toHexString() });
                                                                                                                     //
      var body_html = SSR.render("confirmLoaBody", { numberPortingRequest: numberPortingRequest, account: account, editNumberPortingRequestUrl: editNumberPortingRequestUrl });
                                                                                                                     //
      Email.send({                                                                                                   // 15
        to: account.username,                                                                                        // 16
        from: "noreply@green-bot.com",                                                                               // 17
        subject: 'Please review and confirm your number porting request details for number: ' + NumberPortingRequests.number,
        html: body_html                                                                                              // 19
      });                                                                                                            //
    }                                                                                                                //
                                                                                                                     //
    return sendConfirmLoaEmail;                                                                                      //
  }()                                                                                                                //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods":{"add_network.coffee":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/methods/add_network.coffee.js                                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                     // 1
  'addNetwork': function(botId, network, handle, keywords) {                                                         // 2
    var address, name, networkHandle;                                                                                // 4
    name = network + "::" + handle;                                                                                  // 4
    networkHandle = NetworkHandles.insert({                                                                          // 4
      allocated: true,                                                                                               // 6
      handle: handle,                                                                                                // 6
      network: network,                                                                                              // 6
      keywords: keywords.split(","),                                                                                 // 6
      "default": false,                                                                                              // 6
      userId: Meteor.userId(),                                                                                       // 6
      name: name                                                                                                     // 6
    });                                                                                                              //
    console.log("Added new network handle");                                                                         // 4
    console.log(networkHandle);                                                                                      // 4
    address = {                                                                                                      // 4
      networkHandleId: networkHandle,                                                                                // 18
      networkHandleName: name,                                                                                       // 18
      keywords: keywords.split(","),                                                                                 // 18
      network: network                                                                                               // 18
    };                                                                                                               //
    return Bots.update({                                                                                             //
      _id: botId                                                                                                     // 22
    }, {                                                                                                             //
      $push: {                                                                                                       // 23
        'addresses': address                                                                                         // 23
      }                                                                                                              //
    });                                                                                                              //
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"delete_bot.coffee":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/methods/delete_bot.coffee.js                                                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                     // 1
  'deleteBot': function(botId) {                                                                                     // 1
    Bots.remove({                                                                                                    // 3
      _id: botId                                                                                                     // 3
    });                                                                                                              //
    return console.log("Bot " + botId + " removed from collection");                                                 //
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"install_script.coffee":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/methods/install_script.coffee.js                                                                           //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
                                                                                                                     // 1
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"update_setting.coffee":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/methods/update_setting.coffee.js                                                                           //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                     // 1
  'updateSetting': function(botId, name, value) {                                                                    // 2
    return Bots.update({                                                                                             //
      _id: botId,                                                                                                    // 3
      'settings.name': name                                                                                          // 3
    }, {                                                                                                             //
      $set: {                                                                                                        // 4
        'settings.$.value': value                                                                                    // 4
      }                                                                                                              //
    });                                                                                                              //
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"numberPorting":{"complete_porting.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/numberPorting/complete_porting.js                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Meteor.methods({                                                                                                     // 1
  completePorting: function () {                                                                                     // 2
    function completePorting(numberPortingRequestIds) {                                                              // 2
      NumberPortingRequests.update({ _id: { $in: numberPortingRequestIds } }, { $set: { portingCompletedAt: new Date() } }, { multi: true });
                                                                                                                     //
      NumberPortingRequests.find({ _id: { $in: numberPortingRequestIds } }).forEach(function (e) {                   // 5
        NetworkHandles.insert({ allocated: true, handle: e.number, numberPortingRequestId: e._id, accountId: e.accountId, network: 'tsg' });
      });                                                                                                            //
    }                                                                                                                //
                                                                                                                     //
    return completePorting;                                                                                          //
  }()                                                                                                                //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"start_porting.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/numberPorting/start_porting.js                                                                             //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Meteor.methods({                                                                                                     // 1
  startPorting: function () {                                                                                        // 2
    function startPorting(numberPortingRequestIds) {                                                                 // 2
      NumberPortingRequests.update({ _id: { $in: numberPortingRequestIds } }, { $set: { portingStartedAt: new Date() } }, { multi: true });
    }                                                                                                                //
                                                                                                                     //
    return startPorting;                                                                                             //
  }()                                                                                                                //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"publications":{"bots.coffee":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/publications/bots.coffee.js                                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish("bots", function() {                                                                                  // 1
  return Bots.find({                                                                                                 // 2
    accountId: this.userId                                                                                           // 2
  });                                                                                                                //
});                                                                                                                  // 1
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"scripts.coffee":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/publications/scripts.coffee.js                                                                             //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish("scripts", function() {                                                                               // 1
  return Scripts.find();                                                                                             // 2
});                                                                                                                  // 1
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"sessions.coffee":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/publications/sessions.coffee.js                                                                            //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish("sessions", function(botId) {                                                                         // 1
  console.log("Starting sessions publish for " + botId);                                                             // 2
  return Sessions.find({                                                                                             // 3
    botId: botId                                                                                                     // 3
  });                                                                                                                //
});                                                                                                                  // 1
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"authentication.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/authentication.js                                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Meteor.methods({                                                                                                     // 1
  checkIsAdmin: function () {                                                                                        // 2
    function checkIsAdmin(email) {                                                                                   // 2
      user = Meteor.users.findOne({ "emails.address": email, "isAdmin": true });                                     // 3
      if (!user) throw new Meteor.Error("AuthError", "Authentication failed", "");                                   // 4
    }                                                                                                                //
                                                                                                                     //
    return checkIsAdmin;                                                                                             //
  }()                                                                                                                //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"collection_timestamps.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/collection_timestamps.js                                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Mongo.Collection.getAll().forEach(function (collection) {                                                            // 1
                                                                                                                     //
  collection.instance.before.insert(function (userId, doc) {                                                         // 3
    doc.createdAt = new Date();                                                                                      // 4
  });                                                                                                                //
                                                                                                                     //
  collection.instance.before.update(function (userId, doc, fieldNames, modifier, options) {                          // 7
    if (!modifier.$set) modifier.$set = {};                                                                          // 8
                                                                                                                     //
    modifier.$set.updatedAt = new Date();                                                                            // 11
  });                                                                                                                //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"login_admin_with_password.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/login_admin_with_password.js                                                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{"extensions":[".js",".json",".coffee"]});
require("./lib/collections/admin_users.js");
require("./lib/collections/bots.js");
require("./lib/collections/customers.js");
require("./lib/collections/network_handles.js");
require("./lib/collections/networks.js");
require("./lib/collections/number_porting_requests.js");
require("./lib/collections/rooms.js");
require("./lib/collections/scripts.js");
require("./lib/collections/sessions.js");
require("./lib/router.js");
require("./server/api/1_restivus-init.js");
require("./server/api/plivo.js");
require("./server/config/environment.coffee");
require("./server/emails/confirm_loa.js");
require("./server/methods/add_network.coffee");
require("./server/methods/delete_bot.coffee");
require("./server/methods/install_script.coffee");
require("./server/methods/update_setting.coffee");
require("./server/numberPorting/complete_porting.js");
require("./server/numberPorting/start_porting.js");
require("./server/publications/bots.coffee");
require("./server/publications/scripts.coffee");
require("./server/publications/sessions.coffee");
require("./server/authentication.js");
require("./server/collection_timestamps.js");
require("./server/login_admin_with_password.js");
//# sourceMappingURL=app.js.map
